# Sunsetrise Release Notes
# --------------------------------------------------------------------
# Date: <DD-MMM-YYYY>
Example: 16-JAN-2
# Supported Mule Runtime Versions: 
3.6.0
