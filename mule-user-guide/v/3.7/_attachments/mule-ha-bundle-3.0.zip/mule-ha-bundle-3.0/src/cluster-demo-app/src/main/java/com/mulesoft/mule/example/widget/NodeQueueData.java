/*
 * $Id: URIBuilder.java 23505 2011-12-20 08:20:49Z mike.schilling $
 * --------------------------------------------------------------------------------------
 * Copyright (c) MuleSoft, Inc.  All rights reserved.  http://www.mulesoft.com
 *
 * The software in this package is published under the terms of the CPAL v1.0
 * license, a copy of which has been included with this distribution in the
 * LICENSE.txt file.
 */
package com.mulesoft.mule.example.widget;

import java.util.List;

/**
 * Data for all of a node's queues
 */
public class NodeQueueData
{
    private int nodeNumber;
    private List<QueueData> queueData;

    public NodeQueueData(int nodeNumber, List<QueueData> queueData)
    {
        this.queueData = queueData;
        this.nodeNumber = nodeNumber;
    }

    public int getNodeNumber()
    {
        return nodeNumber;
    }

    public void setNodeNumber(int nodeNumber)
    {
        this.nodeNumber = nodeNumber;
    }

    public List<QueueData> getQueueData()
    {
        return queueData;
    }

    public void setQueueData(List<QueueData> queueData)
    {
        this.queueData = queueData;
    }
}
