/*
 * $Id: Widget.java 18092 2010-10-27 17:15:44Z travis.carlson $
 * --------------------------------------------------------------------------------------
 *
 * (c) 2003-2010 MuleSoft, Inc. This software is protected under international copyright
 * law. All use of this software is subject to MuleSoft's Master Subscription Agreement
 * (or other master license agreement) separately entered into in writing between you and
 * MuleSoft. If such an agreement is not in place, you may not use the software.
 */
package models;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

public class Widget implements Serializable
{
    private static final long serialVersionUID = 8260166525717658609L;

    private String manufacturer;
    
    private String shape;
    
    private String color;

    private String label;
    
    private List<Integer> nodesVisited;

    private long creationTimestamp;

    private long timeToComplete;

    private String id;

    public Widget()
    {
        nodesVisited = new ArrayList<Integer>();
    }

    @Override
    public String toString()
    {
        return "Widget id: "+id+" with label " + (label != null ? " [" + label + "]" : "") + " is a " + color + " " + shape + ", manufactured by "
                + manufacturer + ". Nodes visited were " + nodesVisited + "\n";
    }

    public String getShape()
    {
        return shape;
    }

    public void setShape(String shape)
    {
        this.shape = shape;
    }

    public String getColor()
    {
        return color;
    }

    public void setColor(String color)
    {
        this.color = color;
    }

    public String getLabel()
    {
        return label;
    }

    public void setLabel(String label)
    {
        this.label = label;
    }

    public String getManufacturer()
    {
        return manufacturer;
    }

    public void setManufacturer(String manufacturer)
    {
        this.manufacturer = manufacturer;
    }

    public List<Integer> getNodesVisited()
    {
        return nodesVisited;
    }

    public void setNodesVisited(List<Integer> nodesVisited)
    {
        this.nodesVisited = nodesVisited;
    }
    
    public void addVisitedNode(int node)
    {
        if(this.nodesVisited==null){
            this.nodesVisited = new ArrayList<Integer>();
        }
        this.nodesVisited.add(node);
    }

    public long getCreationTimestamp() {
        return creationTimestamp;
    }

    public void setCreationTimestamp(long creationTimestamp) {
        this.creationTimestamp = creationTimestamp;
    }

    public long getTimeToComplete() {
        return timeToComplete;
    }

    public void setTimeToComplete(long timeToComplete) {
        this.timeToComplete = timeToComplete;
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }
}


