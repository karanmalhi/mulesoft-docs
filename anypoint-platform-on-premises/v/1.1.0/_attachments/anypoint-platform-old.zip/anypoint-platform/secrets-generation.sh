#!/usr/bin/env bash

# ---

set -u
set -e

# ---

echo "Creating platform secrets"
docker run -it --rm \
  -v $PWD/config/authentication-server/api/config/local.js:/usr/src/app/api/config/local.js:ro \
  -v $PWD/config:/usr/src/app/platform-config:rw \
   `grep authentication-server docker-compose.yml | grep image | awk '{print $2;}'` \
   node /usr/src/app/bin/generate_secrets.js

