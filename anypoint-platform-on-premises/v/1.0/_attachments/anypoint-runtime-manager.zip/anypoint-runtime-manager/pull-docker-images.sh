#!/bin/bash

echo "Pulling docker images ..."

for i in $( grep image: *yml | sed -e 's/^.*image://g' | sort -u ); do
    docker pull $i
done

