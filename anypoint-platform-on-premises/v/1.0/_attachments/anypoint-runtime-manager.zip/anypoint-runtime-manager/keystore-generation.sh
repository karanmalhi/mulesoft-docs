#!/bin/bash

replace_arm_keystore(){
  ARM_KEYSTORE=config/hybrid-rest/hybrid.onprem.keystore.jks
  TRUSTSTORE=truststore.jks
  ARM_OVERRIDE_PROPERTIES=config/hybrid-rest/override.properties

  echo "*** Generating ARM Keystore. *** "
  echo "NOTE: This keystore is used as part of the registration process to sign the Mule/Gateway runtime certificates."

  echo -n "Keystore Password:"
  read -s PASSWORD

  rm -rf $ARM_KEYSTORE $TRUSTSTORE
  keytool -genkey -alias onprem -keyalg RSA -keystore $ARM_KEYSTORE -keysize 2048 -keypass $PASSWORD -storepass $PASSWORD
  keytool -exportcert -keystore $ARM_KEYSTORE -alias onprem -storepass $PASSWORD -keypass $PASSWORD -file onprem.cer
  keytool -importcert -keystore $TRUSTSTORE -alias onprem -file onprem.cer -noprompt -storepass $PASSWORD
  rm -rf onprem.cer

  UUID=`uuid`
  awk -F"=" -v newpass="$PASSWORD" 'BEGIN{FS=OFS="="}/hybrid.keystore.password/{$2=newpass;print;next}1' $ARM_OVERRIDE_PROPERTIES |
  awk -F"=" -v newpass="$PASSWORD" 'BEGIN{FS=OFS="="}/hybrid.keypair.alias.password/{$2=newpass;print;next}1' | 
  awk -F"=" -v newuuid="$UUID" 'BEGIN{FS=OFS="="}/hybrid.configuration.encryption.key/{$2=newuuid;print;next}1' > temp.properties

  mv temp.properties $ARM_OVERRIDE_PROPERTIES

  echo ""
  echo "*** Finished Generating ARM Keystore and replacing configuration files. ***" 
  echo "*** New Mule/Gateway truststore file generated: $TRUSTSTORE ***"
  echo "*** Please copy this truststore file to the conf folder of every Mule/Gateway you wish to register with your on-prem platform. ***"
  echo "" 
}

replace_key_and_cert_in_ssl_folder() {
  echo ""
  echo "*** Generating Authentication Server Key and Certificate ***"
  echo "NOTE: This key and certificate is used internally by the MuleSoft authentication service."
  echo "It does not take the place of your corporate signed certificate used for SSL."

  openssl req -x509 -newkey rsa:2048 -nodes -keyout config/ssl/key.pem -out config/ssl/cert.pem -days 3600
}

echo "This script will replace encryption keys, certificates, and keystores included in the installation package with newly generated ones that are self-signed."
echo "This script requires the java keytool executable, openssl, and uuid."
echo "If those binaries do not exist then the script will exit.  Follow the instructions appropriate to your operating system to install them."
echo ""

command -v keytool >/dev/null 2>&1 || { echo >&2 "keytool command not installed.  Aborting."; exit 1; }
command -v openssl >/dev/null 2>&1 || { echo >&2 "openssl not installed.  Aborting."; exit 1; }
command -v uuid >/dev/null 2>&1 || { echo >&2 "uuid not installed.  Aborting."; exit 1; }

replace_arm_keystore
replace_key_and_cert_in_ssl_folder

echo "*** Finished ***"
