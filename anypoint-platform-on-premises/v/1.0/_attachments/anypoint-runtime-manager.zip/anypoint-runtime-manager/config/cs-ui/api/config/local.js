'use strict';

module.exports = {
  https: {
    enabled: false
  }
};
