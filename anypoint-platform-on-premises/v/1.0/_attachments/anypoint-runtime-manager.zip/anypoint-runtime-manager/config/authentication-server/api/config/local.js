'use strict';

var path = require('path');
var root = path.normalize(__dirname + '/../..');

module.exports = {
  urls: {
    cloudhub : {
      base : 'https://nginx/hybrid'
    }
  },

  database: {
    connection: {
      host:     'authdb',
      user:     'docker',
      password: 'docker'
    }
  },

  session : {
    secret: 'defaultSessionSecret'
  },

  crypto : {
    password : 'defaultClientSecretEncryption'
  },

  admin : {
    client : {
      client_id : 'adminclient',
      client_secret : 'defaultAdminClientSecret'
    }
  },

  auth : {
    saml_private_pem : path.join(root, 'api/config/ssl/key.pem')
  },

  https : {
    enabled : false
  },

  cors : {
    allowedOrigins : [
      'https://localhost'
    ]
  },

  adminUI: {
    view: false
  },

  cloudhub: {
    notifyOfSignups: false,
    view: true,
    validateWorkers: false,
    service: './services/cloudhub_service_mock'
  },

  exchange: {
    view: false
  },

  api_platform: {
    view: false,
    service: './services/api_platform_service_mock'
  },

  support: {
    view: false
  },

  features: {
    setup: true
  },

  audit_logging: {
    enabled: false
  },

  environments: {
    deleteRequests: [
      {'Applications': 'https://nginx/hybrid/api/v1/admin/servers?orgId={{organization}}&envId={{environment}}'}
    ],

    roleGroups: [{
      name: 'Application Admin (%s)',
      description: 'Application (%s) Admin users',
      roles: [
        '674c9f7a-ee81-44d7-b25f-eb938d8e69b1', // Read Applications
        '3c91e5ca-fe58-441f-b6ab-a2be0a684bbf', // Create Applications
        '4b3b5050-2f33-4740-9b63-dccc421b9f92', // Delete Applications
        '4e2a978e-0c79-4131-bebf-a653fd8ba039', // Download Applications
        '4db01de7-89db-473e-8591-606204e9baab', // Manage Settings
        '8b7caaba-e94a-11e4-b02c-1681e6b88ec1', // Read Servers
        '53823f29-6e57-4c42-acdb-e42a881a888f'  // Manage Servers
      ],
      isCloudhubAdmin: true
    }, {
      name: 'Appication Developer (%s)',
      description: 'Application (%s) Developer users',
      roles: [
        '674c9f7a-ee81-44d7-b25f-eb938d8e69b1', // Read Applications
        '3c91e5ca-fe58-441f-b6ab-a2be0a684bbf', // Create Applications
        '4e2a978e-0c79-4131-bebf-a653fd8ba039', // Download Applications
        '4db01de7-89db-473e-8591-606204e9baab', // Manage Settings
        '8b7caaba-e94a-11e4-b02c-1681e6b88ec1'  // Read Servers
      ]
    }, {
      name: 'Application Support (%s)',
      description: 'Application (%s) Support users',
      roles: [
        '674c9f7a-ee81-44d7-b25f-eb938d8e69b1' // Read Applications
      ]
    }]
  },

  organizations: {
    deleteRequests : [
      {'Applications': 'https://nginx/hybrid/api/v1/admin/servers?orgId={{organization}}'}      
    ],

    entitlements: {
      createEnvironments: true,
      createSubOrgs:      true,
      globalDeployment:   false,
      hybrid: {
        enabled: true
      },
      vCoresProduction: {
        assigned:   0,
        reassigned: 0
      },
      vCoresSandbox: {
        assigned:   0,
        reassigned: 0
      },
      staticIps: {
        assigned: 0,
        reassigned: 0
      },
      workerLoggingOverride: {
        enabled: false
      }
    },

    subscription: {
      type: 'On-premises',
      expiration: 365
    },

    roleGroups: {
      master: [
        {
          name: 'Organization Administrators',
          description: 'Organization Administrators',
          roles: ['d74ef94a-4292-4896-b860-b05bd7f90d6d', '674c9f7a-ee81-44d7-b25f-eb938d8ebaa1']
        }
      ],

      subOrg: [
        {
          name: 'Organization Administrators',
          description: 'Organization Administrators',
          roles: ['d74ef94a-4292-4896-b860-b05bd7f90d6d', '674c9f7a-ee81-44d7-b25f-eb938d8ebaa1']
        }
      ]
    }
  },

  cloudhubRoles : {
    shared : [
      {
        id: '3c91e5ca-fe58-441f-b6ab-a2be0a684bbf',
        name: 'Create Applications'
      },
      {
        id: '4b3b5050-2f33-4740-9b63-dccc421b9f92',
        name: 'Delete Applications'
      },
      {
        id: '4e2a978e-0c79-4131-bebf-a653fd8ba039',
        name: 'Download Applications'
      },
      {
        id: '4db01de7-89db-473e-8591-606204e9baab',
        name: 'Manage Settings'
      },
      {
        id: '674c9f7a-ee81-44d7-b25f-eb938d8e69b1',
        name: 'Read Applications'
      }
    ],
    hybridOnly : [
      {
        id: '8b7caaba-e94a-11e4-b02c-1681e6b88ec1',
        name: 'Read Servers'
      },
      {
        id: '53823f29-6e57-4c42-acdb-e42a881a888f',
        name: 'Manage Servers'
      }
    ]
  }
};
