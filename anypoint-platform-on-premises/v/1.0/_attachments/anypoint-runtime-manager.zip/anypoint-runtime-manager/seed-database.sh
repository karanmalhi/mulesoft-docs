#!/usr/bin/env bash

# ---

set -u
set -e

# ---

echo "Seeding authentication-server database ..."
docker exec -it `docker ps | grep authentication-server | cut -d " " -f 1` npm run grunt -- migration_onprem

echo "Seeding object-store database ..."
docker exec -it `docker ps | grep object-store | grep -v db | cut -d " " -f 1` npm run knex -- migrate:latest

echo "Seeding runtime management database ..."
docker exec -it `docker ps | grep hybrid-rest | head -n 1 | cut -d " " -f 1` /usr/local/bin/migrate.sh

echo "Forcing a restart of the runtime management service after db migration ..."
docker ps | grep hybrid-rest | cut -d " " -f 1 | xargs docker stop

echo "Done."
