#!/usr/bin/env bash

# ---

set -u
set -e

# ---

echo "Seeding authentication-server database ..."
docker exec -it `docker ps | grep authentication-server | grep -v db | cut -d " " -f 1` npm run grunt -- seedprem

echo "Seeding object-store database ..."
docker exec -it `docker ps | grep object-store | grep -v db | cut -d " " -f 1` npm run -- knex migrate:latest

echo "Done."
