#!/bin/bash

echo "Pulling docker images ..."

for i in $( grep image: *yml | sed -e 's/^.*image://g' | grep -v rancher | sort -u ); do
    docker pull $i
done

