'use strict';

module.exports = {
  authorization: {
    token:     'defaultApiportalToken'
  },

  database: {
    client:     'pg',
    connection: {
      host:     'apiplatformdb',
      user:     'postgres',
      password: '',
      database: 'postgres',
      charset:  'utf8'
    }
  },

  // publicly reachable URLs
  apiPlatformSite: {
    baseUri: '/apiplatform'
  },

  csSite: {
    baseUri: '/accounts',
  },

  chSite: {
    baseUri: '/cloudhub'
  },

  hybridSite: {
    baseUri: '/cloudhub'
  },

  apiNotebook: {
    baseUri: '/notebook'
  },

  mockingService: {
    baseUri: '/raml-mocking-service-site'
  },

  // These are the default values for the feature-enabling flags.
  features: {
    analytics:            false,
    auditLogging:         false,
    cloudHubDeployment:   false,
    hybridDeployment:     true,
    segmentio:            false,
    partyIdIntegration:   false,
    filterCHEnvironments: false,
    remoteLandingContent: false
  },

  objectService: {
    $type: 'objectStore',

    objectStore: {
      baseUri: 'http://objectstore:3000'
    }
  },

  csSiteDirect: {
    baseUri: 'http://authentication:3004'
  },

  hybridSiteDirect: {
    baseUri: 'http://hybridrest:8080/hybrid'
  },

  chSiteDirect: {
    baseUri: 'https://hybridrest:8080'
  },

  email: {
    $type: 'nodemailer',

    nodemailer: {
    }
  }
};
